# **RanggaCode – ID**

**© 2026 RanggaCode**  
_All rights reserved._

### ▶︎ Ketentuan
- Dilarang memperjualbelikan atau mengklaim ulang sebagian maupun seluruh kode ini tanpa izin tertulis dari Developer.
- Script ini dapat digunakan, dimodifikasi, dan dibagikan ulang **hanya** untuk tujuan pribadi atau pengembangan.
- Atribusi ke **RanggaCode** wajib dicantumkan di setiap salinan atau turunan kode.

### ⚠︎ Penafian
Penggunaan script ini sepenuhnya menjadi tanggung jawab pengguna.  
Developer dan kontributor tidak bertanggung jawab atas kerusakan, pelanggaran hukum, atau kerugian yang timbul akibat penggunaan script ini.